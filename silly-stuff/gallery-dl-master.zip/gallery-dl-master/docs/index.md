# gallery-dl Documentation

- ## [Supported Sites](supportedsites.md)
- ## [Command Line Options](options.md)
- ## [Configuration File Options](configuration.rst)
  - ### [gallery-dl.conf](gallery-dl.conf)
  - ### [gallery-dl-example.conf](gallery-dl-example.conf)
- ## [String Formatting](formatting.md)
